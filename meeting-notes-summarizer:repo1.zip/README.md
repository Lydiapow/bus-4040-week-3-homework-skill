# Meeting Notes Summarizer (Claude Skill)

A Claude "skill" that turns raw, messy meeting notes or transcripts into a clean, structured summary with topics discussed, decisions made, action items (with owner and deadline), and open questions.

## How it works

Claude skills are just a `SKILL.md` file with:
- **Frontmatter** (`name` + `description`) that tells Claude what the skill does and when to use it.
- **Instructions** in the body that Claude follows once the skill is triggered.

See `SKILL.md` in this folder for the full instructions and an example.

## How to use

Upload `SKILL.md` to Claude (or add it to your skills folder), then paste in raw meeting notes and ask for a summary or action items. Claude will output the notes in the structured format defined in the skill.
