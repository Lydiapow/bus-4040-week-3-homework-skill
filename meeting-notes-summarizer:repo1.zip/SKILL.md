---
name: meeting-notes-summarizer
description: Turns raw, messy meeting notes or transcripts into a clean summary with clear action items, owners, and deadlines. Use whenever the user pastes in meeting notes, a transcript, or a rough recap and asks for a summary, minutes, recap, or list of action items/next steps.
---

# Meeting Notes Summarizer

This skill converts unstructured meeting notes into a clear, professional summary that a busy stakeholder could read in under a minute.

## When to use this skill

Trigger this skill any time the user provides:
- Raw meeting notes (bullet points, fragments, typos and all)
- A transcript or partial transcript of a meeting or call
- A rough recap they typed quickly during/after a meeting

And asks for any of: a summary, minutes, recap, action items, next steps, or "clean this up."

## Instructions

1. **Read through the full notes first** before writing anything, so you understand the overall arc of the discussion.
2. **Identify the following categories** from the raw text:
   - Key topics discussed
   - Decisions that were made
   - Action items (tasks someone needs to do)
   - Open questions or unresolved issues
3. **For each action item**, extract or infer:
   - The task itself (short, clear phrasing)
   - The owner (person responsible), if mentioned. If no owner is stated, write "Unassigned."
   - The deadline, if mentioned. If none is stated, write "No deadline given."
4. **Do not invent information.** If the notes don't mention a decision, owner, or deadline, do not guess — mark it as missing rather than filling it in.
5. **Keep the summary concise.** Aim for the shortest version that still captures everything important — prefer short bullet points over paragraphs.

## Output format

Always structure the output exactly like this:

```markdown
## Meeting Summary

**Topics Discussed**
- [topic 1]
- [topic 2]

**Decisions Made**
- [decision 1]
- [decision 2]

**Action Items**
| Task | Owner | Deadline |
|------|-------|----------|
| [task] | [owner or "Unassigned"] | [deadline or "No deadline given"] |

**Open Questions**
- [question 1]
```

If a section has no content (e.g., no open questions were raised), write "None noted" under that heading instead of omitting the section.

## Example

**Input:**
"ok so we talked about the q3 budget, marketing wants more spend on social, sarah said she'd get numbers by friday, still not sure if we're doing the trade show, john to follow up with the vendor"

**Output:**

```markdown
## Meeting Summary

**Topics Discussed**
- Q3 budget allocation
- Marketing spend on social media
- Trade show participation

**Decisions Made**
- Marketing will pursue increased social media spend

**Action Items**
| Task | Owner | Deadline |
|------|-------|----------|
| Provide updated budget numbers | Sarah | Friday |
| Follow up with the vendor | John | No deadline given |

**Open Questions**
- Whether the team will participate in the trade show
```
